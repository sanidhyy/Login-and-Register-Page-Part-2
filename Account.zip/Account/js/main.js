$(function(){
    $("#sign_in").click(function(e) {
        $("#sign-in").delay(100).fadeIn(100);
        $("#sign-up").fadeOut(100);
        e.preventDefault();
    });

    $("#sign_up").click(function(e){
        $("#sign-up").delay(100).fadeIn(100);
        $("#sign-in").fadeOut(100);
        e.preventDefault();
    });
});

function validateSignInForm(){
    user_email = document.getElementById("user-email").value;
    user_pass = document.getElementById("user-pass").value;
    error_msg = document.querySelector(".error-msg-signin");

    var matched_case = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if(!user_email.match(matched_case)){
        error_msg.textContent = "Please Enter a Valid E-mail!";
        return false;
    }

    if(user_pass.length==0){
        error_msg.textContent = "Please Enter a Valid Password!";
        return false;
    }

    return true;

}

function validateSignUpForm(){
    username = document.getElementById("name").value;
    email = document.getElementById("email").value;
    pass = document.getElementById("pass").value;
    re_pass = document.getElementById("re-pass").value;
    error_msg = document.querySelector(".error-msg-signup");

    var matched_case = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if(username.length==0){
        error_msg.textContent = "Please Enter a Valid User Name!";
        return false;
    }

    if(!email.match(matched_case)){
        error_msg.textContent = "Please Enter a Valid E-mail!";
        return false;
    }

    if(pass.length==0){
        error_msg.textContent = "Please Enter a Valid Password!";
        return false;
    }

    if(re_pass!=pass){
        error_msg.textContent = "Password Does not Match!";
        return false;
    }

    return true;

}

