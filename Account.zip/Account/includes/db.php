<?php

$host = "localhost";
$user_name = "root";
$password = "root";
$dbname = "user";
$port = "3306";

$con = mysqli_connect($host, $user_name, $password, $dbname, $port);

if($con){
    return true;
}else{
    return false;
    return mysqli_error($con);
}

?>