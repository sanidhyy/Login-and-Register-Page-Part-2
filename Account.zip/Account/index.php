<?php

include("includes/db.php");

session_start();

if(!isset($_SESSION['user_email'])){

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login and Registration Form Using HTML CSS JS</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="main">

        <!-- Sign up form -->
        <section class="signup" id="sign-up">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Sign up</h2>
                        <p class="error-msg-signup"></p>
                        <form action="" method="POST" class="register-form" id="register-form" autocomplete="off" autocapitalize="off" onsubmit="return validateSignUpForm()" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="name" id="name" placeholder="Your Name"/>
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Your Email"/>
                            </div>
                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="pass" id="pass" placeholder="Password"/>
                            </div>
                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="re_pass" id="re-pass" placeholder="Repeat your password"/>
                            </div>
                            <div class="form-group">
                                <input type="checkbox" name="agree_term" id="agree-term" class="agree-term" />
                                <label for="agree-term" class="label-agree-term"><span><span></span></span>I agree all statements in  <a href="#" class="term-service">Terms of service</a></label>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="signup" id="signup" class="form-submit" value="Register"/>
                            </div>
                        </form>

                        <?php
                        
                        if(isset($_POST['signup'])){

                            $name = mysqli_real_escape_string($con, $_POST['name']);
                            $email = mysqli_real_escape_string($con, $_POST['email']);
                            $pass = mysqli_real_escape_string($con, $_POST['pass']);

                            $sel_user = "SELECT * FROM account WHERE user_email='$email'";

                            $run_user = mysqli_query($con, $sel_user);

                            $count_user = mysqli_num_rows($run_user);

                            if($count_user == 0){

                                        
                                    $user_id = rand(10000, 99999);

                                    $pass_hash = password_hash($pass, PASSWORD_BCRYPT);

                                    $insert_user = "INSERT INTO account (user_id, user_name, user_email, user_pass) VALUES ('$user_id','$name','$email','$pass_hash')";

                                    $run_user = mysqli_query($con, $insert_user);

                                    if($run_user){

                                        $_SESSION['user_email'] = $email;

                                        echo "<script>alert('User Registered Successfully!')</script>";

                                        echo "<script>window.open('dashboard.php','_self')</script>";

                                    }else{

                                        $error = mysqli_error($con);

                                        echo "<script>alert('Error: $error')</script>";

                                        echo "<script>window.open('index.php','_self')</script>";

                                    }

                            }else{

                                echo "<script>alert('User with this E-mail Already Exists!')</script>";

                                echo "<script>window.open('dashboard.php','_self')</script>";

                            }

                        }

                        ?>


                    </div>
                    <div class="signup-image">
                        <figure><img src="images/signup-image.jpg" alt="sing up image"></figure>
                        <a class="signup-image-link" id="sign_in" style="cursor: pointer;">I am already a member</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Sing in  Form -->
        <section class="sign-in" id="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="images/signin-image.jpg" alt="sing up image"></figure>
                        <a class="signup-image-link" id="sign_up" style="cursor: pointer;">Create an account</a>
                    </div>

                    <div class="signin-form">
                        <h2 class="form-title">Sign In</h2>
                        <p class="error-msg-signin"></p>
                        <form method="POST" class="register-form" id="login-form" autocomplete="off" autocapitalize="off" onsubmit="return validateSignInForm()" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="user-email"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="email" name="user_email" id="user-email" placeholder="Your E-mail" />
                            </div>
                            <div class="form-group">
                                <label for="user-pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="user_pass" id="user-pass" placeholder="Password" />
                            </div>
                            <div class="form-group">
                                <input type="checkbox" name="remember_me" id="remember-me" class="agree-term" checked />
                                <label for="remember-me" class="label-agree-term"><span><span></span></span>Remember me</label>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="signin" id="signin" class="form-submit" value="Log in"/>
                            </div>
                        </form>

                        <?php
                        
                        if(isset($_POST['signin'])){

                            $email = mysqli_real_escape_string($con, $_POST['user_email']);
                            $pass = mysqli_real_escape_string($con, $_POST['user_pass']);

                            $sel_user = "SELECT * FROM account WHERE user_email='$email' LIMIT 0,1";

                            $run_user = mysqli_query($con, $sel_user);

                            $count_user = mysqli_num_rows($run_user);

                            if($count_user==0){

                                echo "<script>alert('Invalid User E-mail or Password')</script>";

                                echo "<script>window.open('index.php','_self')</script>";

                            }else{

                                $row_user = mysqli_fetch_array($run_user);

                                $hash = mysqli_real_escape_string($con, $row_user['user_pass']);

                                if(password_verify($pass, $hash)){

                                    $_SESSION['user_email'] = $email;

                                    echo "<script>alert('You are Logged In!')</script>";

                                    echo "<script>window.open('dashboard.php','_self')</script>";

                                }else{

                                    echo "<script>alert('Invalid User E-mail or Password')</script>";

                                    echo "<script>window.open('index.php','_self')</script>";

                                }

                            }

                        }

                        ?>


                        <div class="social-login">
                            <span class="social-label">Or Login with</span>
                            <ul class="socials">
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-facebook"></i></a></li>
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-twitter"></i></a></li>
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-google"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>

<?php

}else{

    echo "<script>alert('You are Logged In!')</script>";
    echo "<script>window.open('dashboard.php','_self')</script>";

}

?>

